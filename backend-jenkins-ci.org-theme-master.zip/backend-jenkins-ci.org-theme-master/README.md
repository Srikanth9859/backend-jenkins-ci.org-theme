Stapler taglib for <http://jenkins.io> theme

This is a convenience layout tag library for building backend application that looks&feels like http://jenkins.io/
